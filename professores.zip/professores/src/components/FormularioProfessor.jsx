import { useState } from "react";
import CampoTexto from "./CampoTexto";

const vazio = {
  nome: "",
  email: "",
  cpf: "",
  disciplina: "",
  data_admissao: "",
};

function FormularioProfessor({ salvar }) {
  const [dados, setDados] = useState(vazio);

  function mudar(e) {
    setDados({ ...dados, [e.target.name]: e.target.value });
  }

  function enviar(e) {
    e.preventDefault();
    salvar(dados);
    setDados(vazio);
  }

  return (
    <form onSubmit={enviar}>
      <CampoTexto label="Nome" name="nome" type="text" value={dados.nome} onChange={mudar} />
      <CampoTexto label="Email" name="email" type="email" value={dados.email} onChange={mudar} />
      <CampoTexto label="CPF" name="cpf" type="text" value={dados.cpf} onChange={mudar} />
      <CampoTexto label="Disciplina" name="disciplina" type="text" value={dados.disciplina} onChange={mudar} />
      <CampoTexto label="Data de admissao" name="data_admissao" type="date" value={dados.data_admissao} onChange={mudar} />
      <button type="submit">Cadastrar</button>
    </form>
  );
}

export default FormularioProfessor;
