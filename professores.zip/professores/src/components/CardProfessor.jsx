function CardProfessor({ professor, excluir }) {
  return (
    <div className="card">
      <h3>{professor.nome}</h3>
      <p>Email: {professor.email}</p>
      <p>CPF: {professor.cpf}</p>
      <p>Disciplina: {professor.disciplina}</p>
      <p>Admissao: {professor.data_admissao}</p>
      <button onClick={() => excluir(professor.id)}>Excluir</button>
    </div>
  );
}

export default CardProfessor;
