import CardProfessor from "./CardProfessor";

function ListaProfessores({ professores, excluir }) {
  return (
    <div>
      {professores.map((p) => (
        <CardProfessor key={p.id} professor={p} excluir={excluir} />
      ))}
    </div>
  );
}

export default ListaProfessores;
