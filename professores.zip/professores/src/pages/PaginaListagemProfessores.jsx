import ListaProfessores from "../components/ListaProfessores";

function PaginaListagemProfessores({ professores, excluir }) {
  return (
    <div>
      <h2>Professores</h2>
      <ListaProfessores professores={professores} excluir={excluir} />
    </div>
  );
}

export default PaginaListagemProfessores;
