import FormularioProfessor from "../components/FormularioProfessor";

function PaginaCadastroProfessor({ salvar }) {
  return (
    <div>
      <h2>Cadastrar Professor</h2>
      <FormularioProfessor salvar={salvar} />
    </div>
  );
}

export default PaginaCadastroProfessor;
