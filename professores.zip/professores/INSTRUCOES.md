# Passos manuais

## 1. db.json
Adicione a chave "professores" (veja db-professores.json) ao lado de "alunos".

## 2. App.jsx
import { listarProfessores, criarProfessor, excluirProfessor } from "./services/professorService";
import PaginaListagemProfessores from "./pages/PaginaListagemProfessores";
import PaginaCadastroProfessor from "./pages/PaginaCadastroProfessor";

const [professores, setProfessores] = useState([]);

useEffect(() => {
  listarProfessores().then(setProfessores);
}, []);

async function salvarprofessor(dados) {
  const novo = await criarProfessor(dados);
  setProfessores([...professores, novo]);
}

async function excluirprofessor(id) {
  await excluirProfessor(id);
  setProfessores(professores.filter((p) => p.id !== id));
}

<Route path="/professores"
  element={<PaginaListagemProfessores professores={professores} excluir={excluirprofessor} />} />
<Route path="/cadastrar-professor"
  element={<PaginaCadastroProfessor salvar={salvarprofessor} />} />

## 3. BarraNavegacao.jsx
<Link to="/professores">Professores</Link>
<Link to="/cadastrar-professor">Cadastrar Professor</Link>
